# PianoKT v4 - non-destructive audit + source extension

This patch adds `extend_catalog.py` to your **existing v3** directory. Do not replace `build.py`, `run_pipeline.py`, `input/`, or `output/`.

## Install

From the original `pianokt_300_auto` directory:

```bash
unzip ~/Downloads/PianoKT_catalog_patch_v4.zip -d .
python extend_catalog.py --audit --out output
```

This writes `output/v4_existing_audit.json` and reports possible duplicate titles/composers, missing reference MIDI files, and non-standard placement of tempo/time-signature events. **It will not remove or alter previously accepted works.** A repeated title can be a separate movement; review duplicates manually.

## Add externally vetted new source records

Prepare `external_candidates_template.csv` by **adding real entries**, with direct HTTPS `midi_url`, `score_url`, `source_url`, and an independently checked `license_url`. Set `license_verification=manually_verified` **only if you personally verified the rights and attribution of both the underlying musical composition and the MIDI/sheet edition**. The `score_url` must point to LilyPond (`.ly`) with two named staff contexts `up/down` or equivalent; the MIDI must contain two note tracks with *matching* track names. Arbitrary two-track files do not qualify. Download URLs are supplied intentionally; redirects and non-HTTPS are rejected.

```bash
python extend_catalog.py --extend --out output --root input --target 300 --manifest external_candidates_template.csv
```

The script backs up existing audit/catalog files, appends validated new candidates, writes a checkpoint after each, and preserves old accepted outputs. `build.process` still checks original MIDI tracks, difficulty, 20–40s phrase boundaries and rights fields. Problematic tempo metadata is **rejected for manual review**, never silently fixed.

## Limits

- **This patch does not magically discover or supply 258 additional licensed songs.** External manifest requires actual licensed source candidates. Existing Mutopia catalogue is already exhausted.
- The audit detects anomalies but does not assert that older tracks were verified correctly. Listen to accepted segments before public deployment.
- Title+composer duplicate check is conservative and can reject legitimate distinct movements; review manually.
- Changes are appended in the existing `output/` directory, and a timestamped backup is created before import.
- No claim that a user-supplied `license_verification` declaration constitutes independent legal verification.
